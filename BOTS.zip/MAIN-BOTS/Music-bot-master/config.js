module.exports = {
    app: {
        px: ',',
        token: 'OTIzMjUwMDk2NDIwODMxMjkz.YcNRqA.K-2We7SOO8iPrxX65nB1UX0a13I',
    },

    opt: {
        DJ: {
            enabled: false,
            roleName: 'DJ',
            commands: ['back', 'clear', 'filter', 'loop', 'pause', 'resume', 'seek', 'shuffle', 'skip', 'stop', 'volume']
        },
        maxVol: 100,
        loopMessage: false,
        discordPlayer: {
            ytdlOptions: {
                quality: 'highestaudio',
                highWaterMark: 1 << 25
            }
        }
    }
};
